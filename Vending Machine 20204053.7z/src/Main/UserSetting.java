package Main;

import Machine.Item.Item;
import Machine.Item.ItemStorageQueue;

import java.io.*;

import static AdminSys.Login.LoginSys.setSavedPassword;
import static AdminSys.system.Sales.DataAnalysis.setSalesGoal;
import static Machine.Item.ItemStorageQueue.setMaxQueueSize;
import static Machine.Money.MoneySystem.moneyBox;
import static Main.MainClass.itemMap;
import static Main.MainClass.itemQueue;

public class UserSetting {
    //Field
    private static final String settingFilePath = "C:\\Temp\\Vending Machine Setting.txt";

    //Method
    public static void loadSetting() {
        try (BufferedReader br = new BufferedReader(new FileReader(settingFilePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.startsWith("#") && line.contains(":")) {
                    line = line.replaceAll("\\s+", "");
                    System.out.println(line);
                    String[] parts = line.split(":");
                    String variableName = parts[0].trim();
                    String value = parts[1].trim();
                    assignValue(variableName, value);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        for(int i=0;i<5;i++){
            System.out.println("================================\n\n");
            itemQueue[i].printLinkedList(20);
            System.out.println("================================\n\n\n\n\n\n");
        }
    }

    public static void assignValue(String variableName, String value) {
        switch (variableName) {
            case "Cash":
                try{
                    String[] elements = value.split(",");
                    moneyBox.setCashAmount(
                            Integer.parseInt(elements[0]),
                            Integer.parseInt(elements[1]),
                            Integer.parseInt(elements[2]),
                            Integer.parseInt(elements[3]),
                            Integer.parseInt(elements[4])
                    );
                }
                catch (NumberFormatException exception){
                    System.out.println("Cash State Load Failed");
                    moneyBox.setCashAmount(5,5,5,5,0);
                }
                break;
            case "Item":
                try{
                    System.out.println(value);
                    String[] elements = value.split(",");      // element 배열에 컴마 단위로 잘라 저장
                    Item buffer = new Item();
                    /*for(String s:elements)
                        System.out.println(elements);*/

                    buffer.setItemCode(Long.parseLong(elements[0]));
                    buffer.setName(elements[1]);
                    buffer.setPrice(Integer.parseInt(elements[2]));
                    buffer.setImage(elements[3]);
                    buffer.printItem();

                    itemMap.add(buffer);
                }
                catch (NumberFormatException e){
                    Item buffer = new Item();
                    /*for(String s:elements)
                        System.out.println(elements);*/

                    buffer.setItemCode(0L);
                    buffer.setName("None");
                    buffer.setPrice(10);
                    buffer.setImage("MenuE.png");
                    buffer.printItem();

                    itemMap.add(buffer);
                    System.out.println("Item Load Failed");
                }
                break;
            case "SalesGoal":
                try {setSalesGoal(Integer.parseInt(value));}
                catch (NumberFormatException exception){
                    setSalesGoal(2500);
                    System.out.println("Sales Goal Load Failed");
                }
                break;
            case "Password":
                setSavedPassword(value);
                break;
            case "MaxQueueSize":
                try{setMaxQueueSize(Integer.parseInt(value));}
                catch (NumberFormatException exception){
                    setMaxQueueSize(15);
                    System.out.println("Max Queue Size Load Failed");
                }
                break;
            case "Queue":
                try{
                    String[] elements = value.split(",");
                    int index = Integer.parseInt(elements[0]);
                    System.out.println("index : " + index);
                    System.out.println("ele1 : " + Long.parseLong(elements[1]));
                    System.out.println("ele2 : " + elements[2]);
                    itemQueue[index]
                            = new ItemStorageQueue(Long.parseLong(elements[1]),Integer.parseInt(elements[2]));
                }
                catch (NumberFormatException ignore){
                    System.out.println("Queue Line Load Failed");
                }
                break;
            default:
                System.out.println("Unknown variable: " + variableName);
        }
    }

}
