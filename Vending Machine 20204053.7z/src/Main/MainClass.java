package Main;

import AdminSys.AdminSysMain;
import AdminSys.Time;
import AdminSys.system.Sales.*;
import Machine.Frame.mainFrame;
import Machine.Item.ItemKeyMap;
import Machine.Item.ItemStorageQueue;

import javax.swing.*;
import java.io.*;
import java.util.Scanner;

import static Machine.Frame.InsertCashFrame.insertValue;
import static Machine.Money.MoneySystem.insertCashTotal;
import static Machine.Money.MoneySystem.refreshCashTotal;
import static Main.UserSetting.loadSetting;

public class MainClass {
    public static final String title = "2023 Java Programming - 20204053 임창환";
    public static final String version = "Version : 23H1 (23. 05.)";
    public static AdminSysMain adminSysMain;

    public static ItemKeyMap itemMap = new ItemKeyMap();
    public static ItemStorageQueue itemQueue[] = new ItemStorageQueue[5];


    //===================== 갱신 함수 ==================================

    public static void refreshCashState(){                                                                          //마저 만들 것
        refreshCashTotal();
        mainFrame.refreshCashDisplay();
        if(insertValue!=null)
            insertValue.setText(insertCashTotal + " 원 ");
        if(adminSysMain!=null) {
            if (adminSysMain.adminSysLobby != null)
                adminSysMain.adminSysLobby.cashGraphRefresh();
            if(adminSysMain.adminSysLobby.cashFrame!=null)
                adminSysMain.adminSysLobby.cashFrame.cashGraphRefresh();
        }
    }
    public static void refreshItemState(){
        mainFrame.refreshItemState();
        if(adminSysMain!=null){
            if(adminSysMain.adminSysLobby!=null){
                adminSysMain.adminSysLobby.itemOverviewRefresh();
                if(adminSysMain.adminSysLobby.productFrame!=null)
                    adminSysMain.adminSysLobby.productFrame.refreshItemAmount();
            }
        }

    }
    public static void refreshStorageState(){
        adminSysMain.adminSysLobby.productFrame.refreshStorageTable();
        
        mainFrame.refreshStorageState();
        /*if(adminSysMain!=null){
            if(adminSysMain.adminSysLobby!=null){
                if(adminSysMain.adminSysLobby.productFrame!=null)
                    adminSysMain.adminSysLobby.productFrame.refreshStorageTable();
            }
        }*/
    }
    public static void refreshSalesState(){
        if(adminSysMain.adminSysLobby!=null)
            adminSysMain.adminSysLobby.salesGraphRefresh();
    }

    private static final int MAX_QUEUE_SIZE = 10;   //재고 Queue 사이즈
    //====================== 파일 로딩 =================================
    /*  //loadQueue()는 Setting.txt로 기능을 이전함에 따라 삭제하였습니다.
    private static void loadQueue(){
        long[] itemCode = new long[5];
        int[] itemAmount = new int[5];
        long[] defaultItem =
                new long[]{8808244100973L,8801094523206L,8801056836016L,8801037040029L,8801056175870L};
        try{
            String filePath = "itemQueue.csv";
            File itemQueueList = new File(filePath);
            Scanner scanner = new Scanner(itemQueueList);                 // file을 로드하고 Scanner 선언

            //////////// 읽기 반복 //////////////////
            for(int i=0;scanner.hasNextLine();i++) {
                String line = scanner.nextLine();                // line String buffer에 저장
                String[] elements = line.split(",");      // element 배열에 컴마 단위로 잘라 저장

                itemCode[i] = Long.parseLong(elements[0].trim());
                itemAmount[i] = Integer.parseInt(elements[1].trim());

            }//end of for
            scanner.close();
            System.out.println("로드 성공");

            for(int i=0;i<5;i++)
                itemQueue[i] = new ItemStorageQueue(itemCode[i],itemAmount[i],MAX_QUEUE_SIZE);
        } //end of try
        catch (FileNotFoundException e){
            System.out.println("Error : 저장된 큐 파일 정보 없음");     // 파일이 없을 경우 파일정보 없음
            System.out.println("재고량을 초기값으로 설정합니다.");
            for(int i=0;i<5;i++)
                itemQueue[i] = new ItemStorageQueue(defaultItem[i]);
        }
        for(int i=0;i<5;i++) itemQueue[i].printLinkedList(15);

    }
     */ //loadQueue()는 Setting.txt로 기능을 이전함에 따라 삭제하였습니다.
    public static void refreshQueue(int index){
        int loop = itemQueue[index].getCurrentSize();
        for(int i=0;i<loop;i++){
            itemQueue[index].dequeue();
        }
        for(int i=0;i<loop;i++){
            itemQueue[index].enqueue();
        }
    }




    //=======================
    public static void off(){
        rewriteSalesData();
    }

    private static void rewriteSalesData(){
        String filePath = "sales data.csv";
        String newContent = "새로운 내용1\n새로운 내용2\n새로운 내용3";

        try {
            // 파일 쓰기
            FileWriter fileWriter = new FileWriter(filePath);
            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            Node current = SalesMain.dataList.getHead();
            // 새로운 내용 출력
            for (int i=0;i< SalesMain.getListSize();i++) {
                SalesDataStruct currentData = current.data;
                String buffer = currentData.dataToString();
                bufferedWriter.write(buffer);
                bufferedWriter.newLine();
                System.out.println(buffer);
                current = current.next;
            }

            // 버퍼 비우고 닫기
            bufferedWriter.flush();
            bufferedWriter.close();

            System.out.println("\n파일 내용이 갱신되었습니다.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //========================== Main ==================================
    public static void main(String[] args) {
        //loadQueue();
        loadSetting();

        new mainFrame();
        adminSysMain = new AdminSysMain();
    }
}



/* 5월 19일 할 일
 *
 * 매출 분석 일별, 월별 콘솔출력으로 일단 만들어놓ㄱ
 * 자판기 본체 디자인 완성해두기
 * => 현금투입구
 * => 상품배출구
 * => 버튼 종류
 *
 */