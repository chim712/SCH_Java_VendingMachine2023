package AdminSys.system.Sales;

public class DataList {
    Node head;
    Node tail;

    public void printList(){
        Node Current = head;
        while(Current!=null){
            Current.data.printData();
            Current = Current.next;
        }
    }

    public void newNode(){
        newNode(null);
    }
    public void newNode(SalesDataStruct data){
        if(head==null) head = tail = new Node(data);
        else{
            tail.next = new Node(data);
            tail = tail.next;
        }
    }

    public Node getHead(){return head;}

    DataList(){
        head = tail = null;
    }
}
