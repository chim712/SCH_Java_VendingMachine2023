package AdminSys.system;

import javax.swing.*;

public class infoFrame extends JDialog {

    infoFrame(){

    }
}
